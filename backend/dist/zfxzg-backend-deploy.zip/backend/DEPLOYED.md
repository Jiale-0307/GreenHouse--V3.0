# 已部署服务维护说明

记录时间：2026-11-04T20:16:34+08:00（Asia/Shanghai）。用户明确授权通过SSH部署，本文不记录任何密码、Cookie或令牌。

- 网站：http://121.43.210.31/；接口文档：http://121.43.210.31/docs。
- 服务器：Alibaba Cloud Linux 4.0.5；1Panel；Docker 26.1.3、Compose 2.27.0。
- 后端目录：`/opt/zfxzg/backend`；服务容器：`backend-backend-1`；绑定 `127.0.0.1:8080`，不直接开放公网8080。
- MySQL：现有`mysql:8.4.13`容器，接入`1panel-network`。实际数据库为小写`zfxzg`；原有空`test`表保留，新增本项目16张表。未修改原数据库账号权限。
- OpenResty：现有`openresty`容器，使用host网络。站点配置`/opt/1panel/www/conf.d/ZFXZG.conf`，静态目录`/opt/1panel/www/sites/ZFXZG/index`。API、WebSocket转发到127.0.0.1:8080，并添加SPA路由回退。
- 管理员用户名为`admin`，密码独立随机生成；初始凭据仅保存在服务器`/root/.zfxzg-platform-admin.json`，权限600。后端`.env`权限600。不要把这些文件发回聊天或上传至代码仓库。
- Docker开机启动已启用，后端重启策略为`unless-stopped`。仅运行1个实例、1个worker。

## 常用维护命令

在服务器终端执行：

```sh
cd /opt/zfxzg/backend
docker compose ps
docker compose logs --tail=100 backend
curl -f http://127.0.0.1:8080/health/ready
```

修改.env后重新创建容器：

```sh
docker compose up -d --force-recreate
```

更新代码后重新构建并启动；服务器默认PyPI下载很慢，本次使用阿里云维护的镜像，版本仍锁定：

```sh
docker compose --progress plain build --build-arg PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/
docker compose up -d
```

修改站点配置后先验证，再平滑重载：

```sh
docker exec openresty nginx -t
# 只有上一条通过后再执行。
docker exec openresty nginx -s reload
```

## 备份与验收

部署前的数据库导出与原`.env`/Compose/站点配置保存在服务器`/opt/zfxzg-deploy-backups/20261104T194327+0800/`，目录权限700；静态前端更新前的备份是`/opt/zfxzg-deploy-backups/frontend-20261104T201417+0800.tar.gz`，文件权限600。备份可能含凭据或业务数据，仅留服务器保管。

实际MySQL建表、结构版本1、20测点初始化、空值、13条认证查询、历史查询、CSRF拒绝、注销后401、API文档、SPA刷新和经OpenResty代理的WebSocket 101/订阅/Ping已验证。容器healthy、无重启；pip check通过。浏览器已实际登录，显示admin、智慧农业大棚与实时连接；截图见`verification/deployed-20261104.jpg`。

浏览器验收修复了前端SDK默认fetch未绑定全局对象的问题，防止Illegal invocation导致请求发不出。修复后的SDK6项测试及前端生产构建通过；服务器已更新静态文件，旧文件保留且有完整备份。

当前是HTTP调试部署，未配置域名HTTPS；MQTT订阅、AI、视频地址与实体控制保持未配置/禁用。页面“实时连接”指网页与后端的WebSocket连接，站点“未连接”和读数null表示本版尚未收到现场数据。EMQX未订阅/修改，PLC/DTU未连接或改动，未下发实体动作。
